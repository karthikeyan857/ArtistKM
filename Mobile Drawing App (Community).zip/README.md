
  # Mobile Drawing App (Community)

  This is a code bundle for Mobile Drawing App (Community). The original project is available at https://www.figma.com/design/PiaT6X51tqz0KWrCyA5LjO/Mobile-Drawing-App--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  